<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Remaining Days Chart</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* در فایل CSS شما */
        @font-face {
            font-family: 'YekanBakhFaNum';
            src: url('/var/www/html/account/assets/YekanBakhFaNum-VF.ttf') format('truetype');
            <script src="https://kit.fontawesome.com/18d40f870f.js" crossorigin="anonymous"></script>
        }
        span#countdown {
    color: #0d6efd;
    font-size: 18px !important;
    font-weight: bold !important;
}
    </style>
</head>
<body>
    <canvas id="remainingDaysChart" width="400" height="170"></canvas>
    <div id="remainingDaysCounter" style="text-align: center; font-family: 'YekanBakhFaNum'; font-size: 15px; margin-top: 12px;">
        <span id="countdown" style="font-family: 'YekanBakhFaNum';"></span>
        روز باقی مانده 
    </div>
    
    <script>
        // اضافه کردن فونت به تنظیمات Chart.js
        Chart.defaults.font.family = 'YekanBakh';

        var remainingDays = <?php echo json_encode($remainingDays); ?>;
        var startCount = 0; // عدد شروع
        var endCount = <?php echo json_encode($remainingDays); ?>; // عدد مورد نظر
        var duration = 2000; // مدت زمان انیمیشن (میلی‌ثانیه)

        var ctx = document.getElementById("remainingDaysChart").getContext("2d");

        var chart = new Chart(ctx, {
            type: "pie", // تغییر نوع نمودار به pie chart
            data: {
                labels: ["روزهای سپری شده", "روزهای باقیمانده"], // تغییر نام مبنا به روزهای سپری شده
                datasets: [
                    {
                        data: [31 - remainingDays, remainingDays],
                        backgroundColor: ["red", "#0d6efd"], // تغییر رنگ‌ها به قرمز و آبی
                        borderWidth: 1,
                    },
                ],
            },
            options: {
                plugins: {
                    legend: {
                        display: true,
                    },
                },
                // تنظیم فونت برای تمام متن‌ها در نمودار
                elements: {
                    text: {
                        font: 'YekanBakh', // استفاده از فونت مشخص شده
                    },
                },
            },
        });

        // انیمیشن شمارنده
        var countdownElement = document.getElementById("countdown");
        function animateCount(currentCount) {
            countdownElement.textContent = currentCount;
            countdownElement.style.fontFamily = 'YekanBakh'; // تنظیم فونت برای متن شمارنده
            

            if (currentCount < endCount) {
                setTimeout(function () {
                    animateCount(currentCount + 1);
                }, duration / (endCount - startCount));
            }
        }

        animateCount(startCount);
    </script>
</body>
</html>
